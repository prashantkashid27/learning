
const express = require('express');
var cors = require('cors')
var bodyParser = require('body-parser')
var exphbs = require('express-handlebars');

/**application routes */
var userRoute = require('./server/modules/user/user.routes');
var discussionRoute = require('./server/modules/discussion/discussion.routes');
var adminRoute = require('./server/modules/admin/admin.routes');
var constants = require('./server/schemas/constant.model');

var app = express();
const path = require('path');
const port = 3000;
app.use(cors())

app.engine('handlebars', exphbs({
    defaultLayout: '',
    layoutsDir: path.join(__dirname, 'server/views')
}));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'server/views'))

/**handle uncaught exception */
process.on('uncaughtException', (error, promise) => {
    console.log(' The error was: ', error);
    return new Error({
        'message': "internal server error"
    });
});
process.on('unhandledRejection', (error, promise) => {
    console.log(' The error was: ', error);
});

//middleware
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json())

/**custom middleware for handling requests */
app.use('/users', userRoute);
app.use('/discussions', discussionRoute);
app.use('/admin', adminRoute);

/**Client routes */
app.use("/", express.static(__dirname + "/dist"));

/**Connect to DB */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var url = constants.DBCONFIG.url;
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true });
mongoose.set('useFindAndModify', false);
var db = mongoose.connection;
db.on('error', () => console.log('connection error'));
db.once('open', async function () {
    console.log('DB connected');
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
