![TravelClick](https://static-tx.travelclick.com/tc-images/logo/travelclick-logo-wide.png "TravelClick")
# MoM Tracker — Application for tracking project specific queries and action items

![Author](https://img.shields.io/badge/Author-TravelClick-blue.svg) 
---

### Technical Requirements
- **`Node >= 10.16.0`**
- **`Angular >= 8.2.4`** 
    - Provides improved performance
- **`Typescript`**
    - Provides Static Typing
    - Angular built with Typescript
- **`Bootstrap 5.3`**
- Consistent Versions of Angular and CSS libraries must be used across module projects

### Workspace Overview
The following is an overview of the project workspace.
```
<project-dir>/
  |- client/                    //  Root of all client (i.e. frontend)
  |  |- app/                    //  Root folder of single page application source files
  |  |- | - app.component.ts    //  Root Container component
  |  |- | - app.modules.ts      //  Common includes
  |  |- | - app.rounting.ts     //  Module routing to be defined in this file
  |  |- index.handlebars        //  Main view of application
  |  |- error.handlebars        //  Used for any error
  |- server/
  |  |- modules/
  |  |  |- user/                //  User module specific functionality
  |  |  |- discussion/          //  Discussion module specific functionality
  |  |- schemas/                // schemas for all models used within MongoDB and referred in mongoose
  |  |- commands/               // to setup initial data
  |  |- views/                  // contains views used to render in browser
  |- .npmrc                     //  Configures NPM to use the Travelclick NPM repo
  |- .gitignore                 //  Contains list of all files which needs to be ignored by git
  |- angular.json               //  Configures Angular cli settings 
  |- package.json               //  Versioning and Dependencies
  |- tsconfig.json              //  Configures Typescript compilation settings
  |- tslint.json              	//  Configure Rules to check coding standards
  |- README.md                  //  Readme file - A brief info about Module
  |- server.js                  //  Base file for setting configurations and defining middlewares
```

### Development Build Process
* npm install           //install dependencies
* npm start             // will create build and start nodemon server
* ng server             // to run angular application
* npm run start-node    // to start node server for local development