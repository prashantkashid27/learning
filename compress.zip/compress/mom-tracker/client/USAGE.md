![TravelClick](https://static-tx.travelclick.com/tc-images/logo/travelclick-logo-wide.png "TravelClick")
# Projects Using Angular 8 Boilerplate
---

>1. **Build Implementation**
>2. **Efficient Content Management**