import { NgModule } from '@angular/core';
import { DashboardComponent } from './dashboard.component';
import { DashboardRouting } from './dashboard.routing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TileCardModule } from 'tc-angular-components';

@NgModule({
    declarations: [
        DashboardComponent
    ],
    imports: [
        NgbModule,
        TileCardModule,
        DashboardRouting
    ],
    exports: [DashboardComponent],
    providers: [],
    bootstrap: [DashboardComponent]
})
export class DashboardModule { }
