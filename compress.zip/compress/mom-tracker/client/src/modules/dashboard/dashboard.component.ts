import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent {
    constructor(private router: Router) { }

    onTileClick(num) {
        switch (num) {
            case 1:
                this.router.navigate(['../app/discussion']);
                break;
            case 2:
                this.router.navigate(['../app/discussion']);
                break;
        }
    }

    onLogout() {
        this.router.navigate(['../login']);
    }
}
