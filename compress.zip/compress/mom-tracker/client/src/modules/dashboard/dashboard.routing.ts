import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';

const routes: Routes = [
    {
        path: '',
        component: DashboardComponent,
        children: [
            { path: '', component: DashboardComponent },
            // { path: 'discussion', loadChildren: () => import('../discussion/discussion.module').then(m => m.DiscussionModule) },
            // { path: 'mom', loadChildren: () => import('../discussion/discussion.module').then(m => m.DiscussionModule) },
        ]
    }
];

export const DashboardRouting: ModuleWithProviders = RouterModule.forChild(routes);
