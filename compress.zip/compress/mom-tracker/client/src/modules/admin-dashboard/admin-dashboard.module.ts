import { NgModule } from '@angular/core';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TileCardModule, ToastModule, DropdownModule } from 'tc-angular-components';
import { AdminDashboardRouting } from './admin-dashboard.routing';
import { UserComponent } from './user/user.component';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ProjectComponent } from './project/project.component';
import { ReleaseComponent } from './release/release.component';
import { CommonModule } from '@angular/common';
import { DiscussionsDataService } from '../core/discussions-data.service';

@NgModule({
    declarations: [
        AdminDashboardComponent,
        UserComponent,
        ProjectComponent,
        ReleaseComponent
    ],
    imports: [
        NgbModule,
        CommonModule,
        TileCardModule,
        ToastModule,
        FormsModule,
        DropdownModule,
        AdminDashboardRouting,
        TableModule
    ],
    exports: [AdminDashboardComponent],
    providers: [DiscussionsDataService],
    bootstrap: [AdminDashboardComponent]
})
export class AdminDashboardModule { }

