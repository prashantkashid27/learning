import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastMessageData } from 'tc-angular-components';
import { HTTPService } from 'src/modules/core/http.service';
import { IProject } from 'src/modules/shared/metaData.data';

@Component({
    selector: 'app-project',
    templateUrl: './project.component.html',
    styleUrls: ['./project.component.scss']
})
export class ProjectComponent implements OnInit {
    modalTitle: string;
    nameErrorMsg: string;
    labelErrorMsg: string;
    projects: IProject[];
    project: IProject;

    // Toaster related data
    toastMessage: ToastMessageData;
    dismiss: boolean;
    showToast: boolean;
    toastType: string;

    activeModalRef: NgbActiveModal;
    columns: Array<{
        field: string,
        header: string,
        filterMatchMode: string
    }>;

    constructor(
        private http: HTTPService,
        private modalService: NgbModal
    ) {
        this.dismiss = false;
        this.showToast = false;

        this.toastMessage = {
            bodyText: '',
            titleText: ''
        };

        this.columns = [
            {
                field: 'name',
                header: 'Project Name',
                filterMatchMode: 'startsWith'
            },
            {
                field: 'label',
                header: 'Project Label',
                filterMatchMode: 'startsWith'
            }
        ];
    }

    ngOnInit() {
        this.getMetaData();
    }

    /**
     * Sets project model to default.
     */
    setDefaultProjectModel() {
        this.project = {
            name: '',
            label: ''
        };
        this.nameErrorMsg = '';
        this.labelErrorMsg = '';
    }

    /**
     * Gets all projects data.
     */
    getMetaData() {
        this.http.get('admin/getMetaData').subscribe((data: any) => {
            this.projects = data.projects;
        }, error => {
            console.log('error', error);
        });
    }

    /**
     * Called on toaster state change
     * @param toastType: type of toaster
     * @param state: true/false => open/close of toast
     */
    toggleToast(toastType: string, state?: boolean) {
        if (toastType === 'success') {
            this.showToast = state;
            this.toastType = 'success';
        } else if (toastType === 'warning') {
            this.showToast = state;
            this.toastType = 'warning';
        }
    }

    /**
     * Opens a modal on click.
     * @param content: template to render
     * @param className: class to apply on modal template
     */
    open(content, className) {
        this.setDefaultProjectModel();

        if (className === undefined || className === null || className === '') {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal tc-normal-modal',
                backdrop: 'static'
            });
        } else {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal ' + className,
                backdrop: 'static'
            });
        }
    }

    onNameChange() {
        if (!this.project.name.length) {
            this.nameErrorMsg = 'Required';
        } else {
            this.nameErrorMsg = '';
        }
    }

    onLabelChange() {
        if (!this.project.label.length) {
            this.labelErrorMsg = 'Required';
        } else {
            this.labelErrorMsg = '';
        }
    }


    /**
     * Adds new project to the projects list and updates current project list
     */
    addProject() {
        if (this.project.name.length && this.project.label.length) {
            const project = {
                name: this.project.name,
                label: this.project.label
            };
            this.http.post('admin/addProject', project).subscribe((res: any) => {
                this.toastMessage = {
                    bodyText: 'Project added successfully',
                    titleText: 'Success'
                };
                this.toggleToast('success', true);
                this.getMetaData();

                // close modal using its reference
                this.activeModalRef.close();
            }, error => {
                console.log('error', error);
                this.toastMessage = {
                    bodyText: 'Please check if you are entering valid project',
                    titleText: 'Warning'
                };
                this.toggleToast('warning', true);
            });
        } else {
            this.onNameChange();
            this.onLabelChange();
        }
    }

}
