export interface IUser {
    _id: any;
    name: IName;
    email: string;
    role: string;
    password?: any;
}

export interface IMapUser {
    firstName: string;
    lastName: string;
    email: string;
    role: string;
}

export interface IName {
    firstName: string;
    lastName: string;
}

