import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { ModuleWithProviders } from '@angular/core';

const routes: Routes = [
    { path: '', component: AdminDashboardComponent }
];

export const AdminDashboardRouting: ModuleWithProviders = RouterModule.forChild(routes);
