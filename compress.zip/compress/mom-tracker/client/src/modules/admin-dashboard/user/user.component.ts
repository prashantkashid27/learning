import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastMessageData } from 'tc-angular-components';
import { HTTPService } from 'src/modules/core/http.service';
import { IUser, IMapUser } from '../admin.data';
import { UserRole } from 'src/modules/shared/users.data';
import { DiscussionsDataService } from 'src/modules/core/discussions-data.service';
import { IUserData } from 'src/modules/models/discussions-data.models';

@Component({
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class UserComponent implements OnInit {
    modalTitle: string;
    user: IUser;
    users: IMapUser[];
    roles: any[] = [];

    columns: Array<{
        field: string,
        header: string,
        filterMatchMode: string
    }>;

    // toaster related data
    toastMessage: ToastMessageData;
    toastType: string;
    dismiss: boolean;
    showToast: boolean;

    activeModalRef: NgbActiveModal;

    defaultSelectedRoleIndex = -1;

    constructor(
        private modalService: NgbModal,
        private http: HTTPService,
        private dataService : DiscussionsDataService
    ) {
        this.dismiss = false;
        this.showToast = false;
        this.toastMessage = {
            bodyText: '',
            titleText: ''
        };

        this.columns = [
            {
                field: 'firstName',
                header: 'First Name',
                filterMatchMode: 'startsWith'
            },
            {
                field: 'lastName',
                header: 'Last Name',
                filterMatchMode: 'startsWith'
            },
            {
                field: 'email',
                header: 'Email',
                filterMatchMode: 'startsWith'
            },
            {
                field: 'role',
                header: 'Role',
                filterMatchMode: 'startsWith'
            }
        ];

    }

    ngOnInit() {
        this.modalTitle = 'Add New User';

        // set user role dropdown
        Object.keys(UserRole).forEach(role => {
            this.roles.push({ name: UserRole[role] });
        });

        // set user model
        this.setDefaultUserModel();

        this.getUsers();
    }

    /**
     * Initialize user model
     */
    setDefaultUserModel() {
        this.user = {
            _id: '',
            name: {
                firstName: '',
                lastName: ''
            },
            email: '',
            role: '',
            password: ''
        };
    }

    /**
     * Gets all users registered.
     */
    getUsers() {
        this.users = [];
        this.dataService.getUsers().subscribe((data: Array<IUserData>) => {
            data.forEach((item) => {
                const user = {
                    firstName: item.fullName.firstName,
                    lastName: item.fullName.lastName,
                    role: item.role,
                    email: item.email,
                };
                this.users.push(user);
            });
        }, (error: any) => {
            console.log('error', error);
        });
    }

    /**
     * Called on toaster state change
     * @param toastType: type of toaster
     * @param state: true/false => open/close of toast
     */
    toggleToast(toastType: string, state?: boolean) {
        if (toastType === 'success') {
            this.showToast = state;
            this.toastType = 'success';
        } else if (toastType === 'warning') {
            this.showToast = state;
            this.toastType = 'warning';
        }
    }

    /**
     * Opens a modal on click.
     * @param content: template to render
     * @param className: class to apply on modal template
     */
    open(content, className) {
        this.setDefaultUserModel();

        if (className === undefined || className === null || className === '') {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal tc-normal-modal',
                backdrop: 'static'
            });
        } else {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal ' + className,
                backdrop: 'static'
            });
        }
    }

    /**
     * Gets called when user selects any role from role dropdown
     * @param $event: selected object
     */
    onSelectionChange($event) {
        this.defaultSelectedRoleIndex = $event.selectedIndex;
        this.user.role = $event.selectedObject.name;
    }

    /**
     * Adds new user to the users data and updates current users list
     */
    addNewUser() {
        const user = {
            firstname: this.user.name.firstName,
            lastname: this.user.name.lastName,
            email: this.user.email,
            password: this.user.password,
            role: this.user.role
        };
        this.http.post('users/addUser', user).subscribe((response: any) => {
            this.toastMessage = {
                bodyText: 'User added successfully',
                titleText: 'Success'
            };
            this.toggleToast('success', true);
            this.getUsers();

            // close modal using its reference
            this.activeModalRef.close();
        }, (error: any) => {
            console.log(error);
            this.toastMessage = {
                bodyText: 'Please check if you are entering valid user',
                titleText: 'Warning'
            };
            this.toggleToast('warning', true);
        });
    }
}
