import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { IRelease } from 'src/modules/shared/metaData.data';
import { ToastMessageData } from 'tc-angular-components';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HTTPService } from 'src/modules/core/http.service';

@Component({
    selector: 'app-release',
    templateUrl: './release.component.html',
    styleUrls: [
        './release.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
})
export class ReleaseComponent implements OnInit {
    modalTitle: string;

    release: IRelease;
    releases: IRelease[] = [];

    // Taoster relate data
    toastMessage: ToastMessageData;
    dismiss: boolean;
    showToast: boolean;
    toastType: string;
    columns: Array<{
        field: string,
        header: string,
        filterMatchMode: string
    }>;

    nameErrorMsg: string;
    labelErrorMsg: string;

    activeModalRef: NgbActiveModal;

    constructor(
        private http: HTTPService,
        private modalService: NgbModal
    ) {
        this.dismiss = false;
        this.showToast = false;
        this.toastMessage = {
            bodyText: '',
            titleText: ''
        };
        this.columns = [
            {
                field: 'name',
                header: 'Release Name',
                filterMatchMode: 'startsWith'
            },
            {
                field: 'label',
                header: 'Release Label',
                filterMatchMode: 'startsWith'
            }
        ];
    }

    ngOnInit() {
        this.getMetaData();
    }

    /**
     * Sets project model to default.
     */
    setDefaultReleaseModel() {
        this.release = {
            name: '',
            label: ''
        };
        this.nameErrorMsg = '';
        this.labelErrorMsg = '';
    }

    onNameChange() {
        if (!this.release.name.length) {
            this.nameErrorMsg = 'Required';
        } else {
            this.nameErrorMsg = '';
        }
    }

    onLabelChange() {
        if (!this.release.label.length) {
            this.labelErrorMsg = 'Required';
        } else {
            this.labelErrorMsg = '';
        }
    }


    /**
     * Gets all release data.
     */
    getMetaData() {
        this.http.get('admin/getMetaData').subscribe((data: any) => {
            this.releases = data.releases;
        }, error => {
            console.log('error', error);
        });
    }

    /**
     * Called on toaster state change
     * @param toastType: type of toaster
     * @param state: true/false => open/close of toast
     */
    toggleToast(toastType: string, state?: boolean) {
        if (toastType === 'success') {
            this.showToast = state;
            this.toastType = 'success';
        } else if (toastType === 'warning') {
            this.showToast = state;
            this.toastType = 'warning';
        }
    }

    /**
     * Opens a modal on click.
     * @param content: template to render
     * @param className: class to apply on modal template
     */
    open(content, className) {
        this.setDefaultReleaseModel();

        if (className === undefined || className === null || className === '') {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal tc-normal-modal',
                backdrop: 'static'
            });
        } else {
            this.activeModalRef = this.modalService.open(content, {
                windowClass: 'tc-modal ' + className,
                backdrop: 'static'
            });
        }
    }

    addRelease() {
        if (this.release.label.length && this.release.name.length) {
            const release = {
                name: this.release.name,
                label: this.release.label
            };
            this.http.post('admin/addRelease', release).subscribe((res: any) => {
                this.toastMessage = {
                    bodyText: 'Release added successfully',
                    titleText: 'Success'
                };
                this.toggleToast('success', true);
                this.getMetaData();

                // close modal using its reference
                this.activeModalRef.close();
            }, error => {
                console.log('error', error);
                this.toastMessage = {
                    bodyText: 'Please check if you are entering valid project',
                    titleText: 'Warning'
                };
                this.toggleToast('warning', true);
            });
        } else {
            this.onLabelChange();
            this.onNameChange();
        }
    }

}
