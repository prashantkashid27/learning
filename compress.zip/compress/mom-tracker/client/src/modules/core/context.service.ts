import { Injectable } from '@angular/core';
import { SearchInfo, IUserForDropdown, IUser, IUserData } from '../models/discussions-data.models';

@Injectable()
export class ContextService {
    private user: string;
    private userEmail: string;
    private searchInfo: SearchInfo;
    userRole: string;
    allUsers: IUserData[];
    metadata: any;

    constructor() {
        this.user = '5e4532e88ee2052460e9cb05';
    }

    setUser(id: string, email: string, role: string) {
        this.user = id;
        this.userEmail = email;
        this.userRole = role;
    }

    getUser(): string {
        return this.user;
    }

    getUserEmail(): string {
        return this.userEmail;
    }

    getUserRole(): string {
        return this.userRole;
    }

    setSearchInfo(searchInfo: SearchInfo) {
        this.searchInfo = searchInfo;
    }

    getSearchInfo(): SearchInfo {
        return this.searchInfo;
    }
    setAllUsers(users : IUserData[]) {
        this.allUsers = users;
    }

    getAllUsers(): IUserData[] {
        return this.allUsers;
    }
    setMetaData(metadata : any) {
        this.metadata = metadata;
    }

    getMetaData() {
        return this.metadata;
    }
}

