import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ContextService } from './context.service';
import { LoaderService } from '../loader/loader.service';
import { finalize } from 'rxjs/operators';

@Injectable()
export class HttpInterceptorService implements HttpInterceptor {
    requestCount = 0;
    constructor(private contextService: ContextService, private loaderService: LoaderService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.requestCount++;
        this.loaderService.show();
        if (this.contextService.getUser()) {
            request = request.clone({
                setHeaders: {
                    user: this.contextService.getUser()
                }
            });
        }
        return next.handle(request).pipe(finalize(() => {
            this.requestCount--;
            if (this.requestCount === 0) {
                this.loaderService.hide();
            }
        }));
    }
}
