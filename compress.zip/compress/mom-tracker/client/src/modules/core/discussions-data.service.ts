import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of, Subject, Observable } from 'rxjs';
import { resourceConfig } from '../constants/discussion-config.constants';
import { HTTPService } from './http.service';
import { IAddQuestion, IUser, IUserForDropdown, IUserData } from '../models/discussions-data.models';
import { map } from 'rxjs/operators';
import { IDiscussion } from '../discussion/discussion.data';
import { ContextService } from './context.service';

/**
 * Application level api-request handlers service
 */
@Injectable()
export class DiscussionsDataService {
    projectIdToSend: string;
    releaseIdToSend: string;
    data: any;
    responseId: string;
    public subject = new Subject<any>();
    respdata: any;

    constructor(
        private http: HttpClient,
        private httpService: HTTPService,
        private contextService: ContextService
    ) { }

    ValidateUserForLogin(urlPath: string, params: any) {
        if (resourceConfig.useLocalData) {
            return of({
                status: 200,
                message: 'Successful'
            });
        } else {
            this.httpService.post(urlPath, params);
        }
    }

    /**
     * Adds new Questions in disucssions data
     * @param data: Discussion data
     */
    postQuestion(data: IAddQuestion) {
        return this.httpService.post('', data);
    }

    /**
     * Adds new Attachment in disucssions data
     * @param data: Discussion data
     */
    postAttachement(data: any, discussionId: string) {
        return this.httpService.post('discussions/uploadfile/' + discussionId, data);
    }

    /**
     * Returns requested attachment
     * @param imageName: unique image name
     */
    getAttachmentURL(imageName: string) {
        return 'http://172.27.61.22:3000/discussions/getImage/' + imageName;
    }

    /**
     * Returns all users
     */
    getUsers(): Observable<IUserData[]> {
        if (this.contextService.getAllUsers()) {
            return new Observable<IUserData[]>(observer => {
                return observer.next(this.contextService.getAllUsers());
            });
        } else {
            return this.httpService.get('users').pipe(map((users: IUser[]) => {
                const parsedUsers = [];
                users.forEach(user => {
                    parsedUsers.push({
                        name: user.name.firstName + ' ' + user.name.lastName,
                        _id: user._id,
                        fullName: {
                            firstName: user.name.firstName,
                            lastName: user.name.lastName,
                        },
                        email: user.email,
                        role: user.role
                    });
                });
                this.contextService.setAllUsers(parsedUsers);
                return parsedUsers;
            }));
        }


    }

    /**
     * Returns project and release metaData.
     */
    getProjectReleaseMetaData() {
        if (this.contextService.getMetaData()) {
            return new Observable(observer => {
                return observer.next(this.contextService.getMetaData());
            });
        } else {
            return this.httpService.get('admin/getMetaData').pipe(map((metadata) => {
                this.contextService.setMetaData(metadata);
                return metadata;
            }));
        }
    }

    /**
     * Adds new Discussion in disucssions data
     * @param data: Discussion data
     */
    addNewDisucssion(data: any) {
        return this.httpService.post('discussions/addDiscussion', data);
    }


    /**
     * Edits Adds existing Response Question Comment
     * @param data: Response data
     */
    editAddData(data: any) {
        return this.httpService.put('discussions/updateDiscussion', data);
    }

    /**
     * Set discussion Id and question Id.
     * @param data: Discussion data
     */
    setDiscussionId(discussionId: any, questionId: any) {
        this.data = {
            discussion: discussionId,
            question: questionId,
        };
    }

    /**
     * Get discussion Id and question Id.
     * @param data: Discussion data
     */
    getDiscussionId() {
        return this.data;
    }

    /**
     * Get discussion data based on particular discussion Id.
     * @param data: Discussion data
     */
    getDetails(data: any) {
        const test = data;
        console.log('test', test);
        return this.httpService.get('discussions/getDiscussion/' + test);
    }

    /**
     * Set response Id to add new reponse.
     * @param data: Discussion data
     */
    setResponseId(responseId: any, quesId: any, discussionId: any) {
        this.respdata = {
            response: responseId,
            question: quesId,
            discussion: discussionId
        };
    }

    /**
     * Get response Id to add new reponse.
     * @param data: Discussion data
     */
    getResponseId() {
        return this.respdata;
    }

    changeDiscussionStatus(payload: object) {
        return this.httpService.patch('discussions/status', payload);
    }

    delete(urlString: string) {
        return this.httpService.delete('discussions/delete' + urlString, {});
    }

    tagResponse(payload) {
        return this.httpService.patch('discussions/tagResponse', payload);
    }

    getDiscussions(payload: object, sortByUpdateTime?: boolean): Observable<IDiscussion[]> {
        if (sortByUpdateTime) {
            return this.httpService.post('discussions/getDiscussions', payload).pipe(map((discussions: IDiscussion[]) => discussions));
        } else {
            return this.httpService.post('discussions/getDiscussions', payload).pipe(map((discussions: IDiscussion[]) => {
                discussions = discussions.sort((a, b) => {
                    return Number(new Date(b.lastupdated)) - Number(new Date(a.lastupdated));
                });
                return discussions;
            }));
        }
    }
}
