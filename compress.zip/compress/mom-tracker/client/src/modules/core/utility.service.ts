import { Injectable } from '@angular/core';

@Injectable()
export class UtilityService {

    baseUrl: string;
    stateURL: string;

    constructor() {
        this.baseUrl = 'http://localhost:4200/#/';
        this.stateURL = 'app/discussion/tracker';
    }

    /**
     * Returns discussion URL
     * @param projectId: project id
     * @param releaseId: release id
     * @param discussionId: discussion id
     */
    getDiscussionUrl(projectId: string, releaseId: string, discussionId: string): string {
        return this.baseUrl + this.stateURL +
            '?project=' + projectId +
            '&release=' + releaseId +
            '&discussion=' + discussionId;
    }

}
