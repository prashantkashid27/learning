
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HTTPService {
    basePath: string;
    constructor(private $http: HttpClient) {
        this.basePath = 'http://localhost:3000/';
    }
    /*
        Http method to get rest API calls
    */
    get(urlPath: string) {
        const url = this.basePath + urlPath;
        return this.$http.get(url);
    }
    /*
        Http method to post rest API calls
    */
    post(urlPath: string, param: any) {
        const url = this.basePath + urlPath;
        return this.$http.post(url, param);
    }
    /*
        Http method to put rest API calls
    */
    put(urlPath: string, param: any) {
        const url = this.basePath + urlPath;
        return this.$http.put(url, param);
    }
    /*
        Http method to delete rest API calls
    */
    delete(urlPath: string, param: any) {
        const url = this.basePath + urlPath;
        return this.$http.delete(url, param);
    }
    /*
        Http method to patch rest API calls
    */
    patch(urlPath: string, param: any) {
        const url = this.basePath + urlPath;
        return this.$http.patch(url, param);
    }
    /*
        Http method to test API call using mock json
    */
    getTest(urlPath: string) {
        return this.$http.get(urlPath);
    }
}

