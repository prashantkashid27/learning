/**
 * Core angular modules
 */
import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContextService } from '../core/context.service';
import { UserRole } from '../shared/users.data';

@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: [
        './home.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
})

/**
 * Root component for template project
 */
export class HomeComponent {


    constructor(
        private router: Router,
        private contextService: ContextService
    ) { }

    onLogout() {
        this.router.navigate(['../login']);
    }

    redirectToHomePage () {
        this.router.navigate(['../app/dashboard']);
    }

    isAdminUser () {
        return this.contextService.getUserRole() === UserRole.ADMIN;
    }

    goToAdminView () {
        this.router.navigate(['/app/adminDashboard']);
    }
  
}
