export interface IDropDown {
    name?: IName;
    id?: number;
    email_id?: string;
    role?: string;
}

export interface IName {
    firstName?: string;
    lastName?: string;
}

export interface IAddQuestion {
    for: Array<string>;
    text: string;
    id?: string;
    responses?: Array<IResponse>;
}

export interface IFor {
    name?: IName;
    _id?: string;
    email?: string;
    role?: string;
}
export interface IResponse {
    date?: string;
    _id?: string;
    text?: string;
}

export interface IAddDiscussion {
    project?: string;
    release?: string;
    reference: string;
    question: IAddQuestion;
    author?: string;
    comments?: string;
}

export interface IEdit {
    project?: string;
    release?: string;
    point: string;
    questions: Array<IAddQuestion>;
    author?: string;
    comments?: string;
    _id: string;
    status?: string;
    attachments?: Array<string>;
    lastupdated?: string;
    __v?: string;
}

export interface IUser {
    _id: any;
    name: IName;
    email?: string;
    role?: string;
    password?: any;
}

export interface IUserData {
    _id: string;
    name: string;
    email?: string;
    role?: string;
    password?: any;
    fullName?: IName;
}

export interface IUserForDropdown {
    _id: string;
    name: IName;
}

export interface SearchInfo {
    project: string;
    release: string;
    status: string;
    for?: string;
    author?: string;
}

export interface ProjectDetails {
    projectId: string;
    releaseId: string;
}

