/**
 * Core angular modules
 */
import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { HTTPService } from '../core/http.service';
import { ContextService } from '../core/context.service';
import { Router } from '@angular/router';
import { UserRole } from '../shared/users.data';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: [
        './login.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
})

/**
 * Root component for template project
 */
export class LoginComponent implements OnInit {

    error: string;
    email = '';
    password = '';
    haserror: {
        email: boolean,
        pwd: boolean
    };

    constructor(
        private http: HTTPService,
        private contextService: ContextService,
        private router: Router
    ) { }

    ngOnInit() {
        this.haserror = {
            email: false,
            pwd: false
        };
    }

    onSubmit() {
        const loginPayload = {
            email: this.email,
            password: this.password
        };

        if (this.email && this.password) {
            this.haserror = {
                email: false,
                pwd: false
            };

            this.http.post('users/authenticate', loginPayload).subscribe((res: any) => {
                if (res) {
                    this.contextService.setUser(res._id, this.email, res.role);
                    this.router.navigate(['app/dashboard']);
                }
            }, (error: any) => {
                this.error = 'Please enter correct Email/Password';
            });

        } else {
            if (!this.email) {
                this.haserror.email = true;
            }
            if (!this.password) {
                this.haserror.pwd = true;
            }
        }
    }
}
