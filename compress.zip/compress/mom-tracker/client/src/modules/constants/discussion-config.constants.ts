export const resourceConfig = {
    useLocalData: true
};
