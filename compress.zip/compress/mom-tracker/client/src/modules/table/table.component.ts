import {
    Component, ViewEncapsulation, OnInit, Input, ViewChild, Output, EventEmitter,
    AfterViewInit, OnChanges
} from '@angular/core';

import { AttachmentsModalComponent } from '../modal-popup/attachments-modal/attachments-modal.component';
import { ViewAttachmentModalComponent } from '../modal-popup/view-attachment-modal/view-attachment-modal.component';
import { ToastMessageData } from 'tc-angular-components';
import { DiscussionsDataService } from '../core/discussions-data.service';
import { EditModalComponent } from '../modal-popup/edit-modals/edit-modals.component';
import { EnmStatus, IDiscussion } from '../discussion/discussion.data';
import { ConfirmationModalComponent } from '../modal-popup/confirmation-modal/confirmation-modal';
import { UtilityService } from '../core/utility.service';

@Component({
    selector: 'app-table',
    templateUrl: './table.component.html',
    styleUrls: [
        './table.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
})
export class TableComponent implements OnInit, OnChanges, AfterViewInit {

    filteredDiscussions: Array<IDiscussion>;
    referenceFilter = '';
    questionFilter = '';
    showSuccessToast: boolean;
    toastMessage: ToastMessageData = {
        bodyText: 'Discussion Data Saved successfully',
        titleText: 'Toast Title'
    };
    result: any;
    status = EnmStatus;
    attachmentSrc: any;
    viewAttachmentLink: any;
    attachments: any;
    images: Array<any> = [];
    prevScrollpos = 0;

    discussionId: any;
    questionId: any;
    responseId: any;
    urlToShare: string;
    @Input() discussions: Array<IDiscussion>;
    @Output() getDiscussions = new EventEmitter();
    /**
     * Id of the current discussion to highlight/select
     */
    @Input() currentDiscussion: string | number;

    /**
     * element ref of modal
     * @memberof AttachmentsModalComponent
     */
    @ViewChild(AttachmentsModalComponent, { static: true }) attachmentModal: AttachmentsModalComponent;

    /**
     * element ref of modal
     * @memberof ViewAttachmentModalComponent
     */
    @ViewChild(ViewAttachmentModalComponent, { static: true }) viewattachmentModal: ViewAttachmentModalComponent;

    /**
     * element ref of Add /Edit Question, Response,Comment modal
     * @memberof EditModalComponent
     */
    @ViewChild(EditModalComponent, { static: true }) editAddModal: EditModalComponent;

    /**
     * element ref of conformation modal
     * @memberof ConfirmationModalComponent
     */
    @ViewChild(ConfirmationModalComponent, { static: true }) confirmModal: ConfirmationModalComponent;

    constructor(
        private dataService: DiscussionsDataService,
        private utilityService: UtilityService
    ) {
        this.showSuccessToast = false;
        this.prevScrollpos = 0;
    }

    ngOnInit() {
        this.filteredDiscussions = this.discussions;
        console.log('filteredDiscussions', this.filteredDiscussions);
    }

    ngOnChanges() {
        this.filteredDiscussions = this.discussions;
        console.log(this.filteredDiscussions);

        // clear filter search of table on getDiscussion()
        this.referenceFilter = '';
        this.questionFilter = '';
    }

    ngAfterViewInit(): void {
        const elem = document.getElementById('redirected-discussion');
        if (elem) {
            elem.scrollIntoView();
        }
    }

    filter() {
        this.filteredDiscussions = this.discussions;
        this.filteredDiscussions = this.filteredDiscussions.filter(discussion => {
            return discussion.point.toLowerCase().includes(this.referenceFilter.toLowerCase());
        });
        this.filteredDiscussions = this.filteredDiscussions.filter(discussion => {
            for (let i = 0; i < discussion.questions.length; i++) {
                if (discussion.questions[i].text
                    && discussion.questions[i].text.toLowerCase().includes(this.questionFilter.toLowerCase())) {
                    return true;
                } else {
                    continue;
                }
            }
        });
    }

    changeStatus(status: EnmStatus, discussionId: string) {
        const payload = {
            status,
            id: discussionId
        };
        this.dataService.changeDiscussionStatus(payload).subscribe((response) => {
            this.refreshDiscussions();
        });
    }

    deleteRecord(discussionId: string, questionId?: string, responseId?: string) {
        this.discussionId = discussionId;
        this.questionId = questionId;
        this.responseId = responseId;
        this.confirmModal.open('Delete Record', 'tc-modal-25');
    }

    toDeleteConfirm() {
        let urlString = '/' + this.discussionId;
        if (this.questionId) {
            urlString += '/' + this.questionId;
            if (this.responseId) {
                urlString += '/' + this.responseId;
            }
        }
        this.dataService.delete(urlString).subscribe((response) => {
            this.refreshDiscussions();
        });
    }

    tagResponse(questionId: string, responseId: string) {
        const payload = {
            qid: questionId,
            rid: responseId,
            tagValue: true
        };
        this.dataService.tagResponse(payload).subscribe(response => {
            this.refreshDiscussions();
        });
    }

    refreshDiscussions() {
        this.getDiscussions.emit();
    }

    /**
     * Shows toast message on success of discussion data saved
     */
    showToast(event) {
        this.showSuccessToast = event;
    }

    /**
     * Opens modal to add new question
     */
    addQuestion(discussionId, questionId) {
        this.dataService.setDiscussionId(discussionId, questionId);
        this.editAddModal.open('Add Question', 'tc-modal-50');
    }

    /**
     * Opens modal to add new response
     */
    addResponse(discussionId, questionId) {
        this.dataService.setDiscussionId(discussionId, questionId);
        this.editAddModal.open('Add Response', 'tc-modal-25');
    }

    /**
     * Opens modal to add new comment
     */
    addComment(discussionId, questionId) {
        this.dataService.setDiscussionId(discussionId, questionId);
        this.editAddModal.open('Add Comment', 'tc-modal-25');
    }

    /**
     * Opens modal to edit existing comment
     */
    editComment(discussionId, questionId) {
        this.dataService.setDiscussionId(discussionId, questionId);
        this.editAddModal.open('Edit Comment', 'tc-modal-25');
    }

    /**
     * Opens modal to edit existing question
     */
    editQuestion(discussionId, questionId) {
        this.dataService.setDiscussionId(discussionId, questionId);
        this.editAddModal.open('Edit Question', 'tc-modal-50');
    }

    /**
     * Opens modal to edit existing response
     */
    editResponse(responseId, quesId, discussionId) {
        console.log('resp Id', discussionId);
        this.dataService.setResponseId(responseId, quesId, discussionId);
        this.editAddModal.open('Edit Response', 'tc-modal-50');
    }

    /**
     * Opens modal to add attachment
     */
    addAttachment(discussionId: string) {
        this.attachmentModal.open('Add Attchment', 'tc-modal-50', discussionId);
    }

    /**
     * Opens modal to view attachment
     */

    viewAttchment(discussionId: string) {
        this.viewAttachmentDatas(discussionId);
        this.viewattachmentModal.open('Add Attchment', 'tc-modal-75', discussionId);
    }

    /**
     * Receives payload to add/edit respective data and further calls respective API
     */
    receivePayload(event) {
        if (event) {
            this.dataService.editAddData(event).subscribe(resp => { this.refreshDiscussions(); }, (error: any) => {
                console.log(error);
            });
        }
    }

    /**
     * Receives payload to view attachment for respective data and further calls respective API
     */
    viewAttachmentDatas(discussionId) {
        this.dataService.getDetails(discussionId).subscribe(resp => {
            this.result = resp;
            this.attachments = this.result.attachments;
            this.result.attachments.forEach((item: any) => {
                this.images.push({ src: 'http://172.27.61.22:3000/discussions/getImage/' + item.fileName });
                console.log('images', this, this.images);
                this.viewAttachmentLink = this.images;
            });

        });
    }

    /**
     * Receives payload to add attachment for respective data and further calls respective API
     */
    addAttachmentData(event) {
        this.dataService
            .postAttachement(event.formData, event.discussion)
            .subscribe(val => {
                console.log(val);
            });
        this.refreshDiscussions();
    }

    /**
     * Copies text field: discussion URL
     * @param element: element whoes text to copy
     */
    copyText(element: string) {
        const copyText: any = document.getElementById(element);

        // Select the text field
        copyText.select();
        copyText.setSelectionRange(0, 99999); /*For mobile devices*/

        // Copy the text inside the text field
        document.execCommand('copy');
    }

    /**
     * Generates URL required to access discussion
     * @param discussionId: discussion id
     */
    generateUrl(discussionId: string) {
        this.urlToShare = this.utilityService.getDiscussionUrl(
            this.filteredDiscussions[0].project,
            this.filteredDiscussions[0].release,
            discussionId
        );
    }
}
