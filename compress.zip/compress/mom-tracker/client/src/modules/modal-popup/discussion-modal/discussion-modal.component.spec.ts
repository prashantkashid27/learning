import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscussionModalComponent } from './discussion-modal.component';

describe('DiscussionModalComponent', () => {
  let component: DiscussionModalComponent;
  let fixture: ComponentFixture<DiscussionModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiscussionModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscussionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
