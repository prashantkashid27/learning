import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Output,
  EventEmitter,
  Input,

} from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { IAddDiscussion, IUserData, ProjectDetails } from '../../models/discussions-data.models';
import { DiscussionsDataService } from '../../core/discussions-data.service';
import { Subscription } from 'rxjs';
import { IRelease } from 'src/modules/shared/metaData.data';

@Component({
  selector: 'discussions-modal',
  templateUrl: './discussion-modal.component.html',
  styleUrls: ['./discussion-modal.component.scss']
})
export class DiscussionModalComponent {
  referenceId: string;
  referenceError = false;
  showComment = false;
  questionValue: string;
  commentValue: string;
  questionError = false;
  showToast = false;

  subscription: Subscription;
  messages: any;
  @Output() toastEmit = new EventEmitter();
  @Input() projectDetails: ProjectDetails;
  @Output() addDiscussionData = new EventEmitter();

  @ViewChild('discussionPopup', { static: true })
  discussionModalContentReference: ElementRef;

  /**
   * holds modal title
   * @memberof DiscussionModalComponent
   */
  modalTitle: string;
  userNameId: Array<any> = [];
  users: Array<IUserData> = [];
  selectedUserIds: Array<string> = [];
  selectedUsers: Array<any> = [];
  projectId: any;
  releaseId: any;
  projectInfo: any;
  activeModalRef: NgbModalRef;
  projectList: any[];
  releaseList: any[];
  defaultProjectSelection: number;
  defaultReleaseSelection: number;

  constructor(
    private modalService: NgbModal,
    private dataService: DiscussionsDataService
  ) { }

  /**
   * function to open modal
   * @param title: string title of the modal
   * @param className: string user defined class name
   * @memberof DiscussionModalComponent
   */

  open(title, className) {
    this.modalTitle = title;
    this.referenceId = '';
    this.questionValue = '';
    this.commentValue = '';
    this.selectedUserIds = [];
    this.dataService.getUsers().subscribe((users: IUserData[]) => {
      this.users = users;
    });
    this.dataService.getProjectReleaseMetaData().subscribe((response: { projects: IRelease[], releases: IRelease[] }) => {
      if (response) {
        this.projectList = response.projects;
        this.releaseList = response.releases;
        // Project and release should be selected only if they are present in the url
        if (this.projectDetails && this.projectDetails.projectId) {
          this.defaultProjectSelection = this.projectList.findIndex((project) => project._id === this.projectDetails.projectId);
        }
        if (this.projectDetails && this.projectDetails.releaseId) {
          this.defaultReleaseSelection = this.releaseList.findIndex((release) => release._id === this.projectDetails.releaseId);
        }
      }
    }, (error: any) => {
      console.log('admin/getMetaData', error);
    });
    if (className === undefined || className === null || className === '') {
      this.activeModalRef = this.modalService.open(this.discussionModalContentReference, {
        windowClass: 'tc-modal tc-normal-modal'
      });
    } else {
      this.activeModalRef = this.modalService.open(this.discussionModalContentReference, {
        windowClass: 'tc-modal ' + className,
        backdrop: 'static',
        keyboard: false
      });
    }
  }

  addComment() {
    this.showComment = true;
  }

  onClose() {
    this.showComment = false;
    const reset = this.selectedUsers.map(item => item.visible = false);
    this.activeModalRef.close();
  }
  onSelectionChange(event) {
    this.selectedUserIds = [];
    const usersList = event.dropdownItems;
    this.selectedUsers = usersList.filter(item => item.visible);
    this.selectedUsers.forEach((user: any) => {
      this.selectedUserIds.push(user['_id']);
    });
  }

  onSelectionChanges(event, isProject) {
    console.log(event);
    if (isProject) {
      this.projectDetails.projectId = event.selectedObject._id;
    } else {
      this.projectDetails.releaseId = event.selectedObject._id;
    }
  }
  /**
   * Sends discussion data payload to parent component
   */
  onAddNewDiscussion() {
    if (!this.referenceId) {
      this.referenceError = true;
    }
    if (!this.questionValue) {
      this.questionError = true;
    }
    if (!this.referenceId || !this.questionValue) {
      return;
    }
    const data: IAddDiscussion = {
      project: this.projectDetails.projectId,
      release: this.projectDetails.releaseId,
      reference: this.referenceId,
      question: {
        text: this.questionValue,
        for: this.selectedUserIds
      },
      comments: this.commentValue
    };
    console.log('newly added discussion data', data);

    if (this.questionValue && this.referenceId) {
      this.addDiscussionData.emit(data);
      this.showToast = true;
      this.modalService.dismissAll('Discussion data saved');
      this.toastEmit.emit(this.showToast);
    } else {
      console.log('Insert all values');
    }
  }
}
