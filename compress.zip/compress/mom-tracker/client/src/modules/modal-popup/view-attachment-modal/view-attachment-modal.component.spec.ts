import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAttachmentModalComponent } from './view-attachment-modal.component';

describe('ViewAttachmentModalComponent', () => {
  let component: ViewAttachmentModalComponent;
  let fixture: ComponentFixture<ViewAttachmentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAttachmentModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAttachmentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
