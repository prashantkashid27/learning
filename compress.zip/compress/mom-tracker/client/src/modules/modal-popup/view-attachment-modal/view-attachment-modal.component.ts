import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, Input, EventEmitter, OnChanges } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DiscussionsDataService } from 'src/modules/core/discussions-data.service';


@Component({
  selector: 'discussions-view-attachment-modal',
  templateUrl: './view-attachment-modal.component.html',
  styleUrls: ['./view-attachment-modal.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ViewAttachmentModalComponent implements OnChanges {

  /**
   * holds modal title
   * @memberof ViewAttachmentModalComponent
   */
  modalTitle: string;
  attachments: any;
  attachmentSrc: any;
  activeModalRef: NgbModalRef;
  imageName: any;
  currentSlide = 0;
  @Input() viewAttachmentLink: any;
  @Output() viewAttachmentDatas = new EventEmitter();
  @Output() refreshDiscussions = new EventEmitter();

  /**
   * element ref of modal
   * @memberof ViewAttachmentModalComponent
   */
  @ViewChild('viewAttachmentPopup', { static: true }) viewAttachmentModalContentReference: ElementRef;


  constructor(private modalService: NgbModal, private dataService: DiscussionsDataService) { }


  ngOnChanges() {
    this.attachmentSrc = this.viewAttachmentLink;
  }
  /**
   * function to open modal
   * @param message: string content of modal
   * @param title: string title of the modal
   * @param className: string user defined class name
   * @memberof ViewAttachmentModalComponent
   */


  open(title: string, className?: string, disucssionId?: any) {
    this.modalTitle = title;
    if (className === undefined || className === null || className === '') {
      this.activeModalRef = this.modalService.open(this.viewAttachmentModalContentReference, { windowClass: 'tc-modal tc-normal-modal' });
    } else {
      this.activeModalRef = this.modalService.open(this.viewAttachmentModalContentReference, {
        windowClass: 'tc-modal ' + className,
        backdrop: 'static'
      });
    }

  }
  /**
   * Emits attached filename to parent component
   */

  getAttachment(imageName: any) {
    this.viewAttachmentDatas.emit(imageName);

  }

  onClose() {
    this.activeModalRef.close();
  }

  onPreviousClick() {
    const previous = this.currentSlide - 1;
    this.currentSlide = previous < 0 ? this.attachmentSrc.length - 1 : previous;
    console.log('previous clicked, new current slide is: ', this.currentSlide);
  }

  onNextClick() {
    const next = this.currentSlide + 1;
    this.currentSlide = next === this.attachmentSrc.length ? 0 : next;
    console.log('next clicked, new current slide is: ', this.currentSlide);
  }
}

