import { Component, OnInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'discussions-confirm-modal',
    templateUrl: './confirmation-modal.html',
    styleUrls: ['./confirmation-modal.scss']
})
export class ConfirmationModalComponent implements OnInit {

    /**
     * holds modal title
     * @memberof ConfirmationModalComponent
     */

    modalTitle: string;
    activeModalRef: NgbModalRef;

    @Output() toDeleteConfirm = new EventEmitter();
    /**
     * element ref of modal
     * @memberof ConfirmationModalComponent
     */
    @ViewChild('confirmationPopup', { static: true })
    confirmationModalComponent: ElementRef;

    constructor(
        private modalService: NgbModal,
    ) { }

    ngOnInit() { }

    open(title, className) {
        this.modalTitle = title;
        if (className === undefined || className === null || className === '') {
            this.activeModalRef = this.modalService.open(this.confirmationModalComponent, {
                windowClass: 'tc-modal tc-normal-modal'
            });
        } else {
            this.activeModalRef = this.modalService.open(this.confirmationModalComponent, {
                windowClass: 'tc-modal ' + className,
                backdrop: 'static',
                keyboard: false
            });
        }
    }

    clickOk() {
        this.toDeleteConfirm.emit();
    }

    clickCancel() {
        this.activeModalRef.close();
    }
}
