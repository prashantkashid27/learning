import { Component, OnInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DiscussionsDataService } from '../../core/discussions-data.service';

@Component({
  selector: 'discussions-attachments-modal',
  templateUrl: './attachments-modal.component.html',
  styleUrls: ['./attachments-modal.component.scss']
})
export class AttachmentsModalComponent implements OnInit {


  /**
   * holds modal title
   * @memberof AttachmentsModalComponent
   */

  modalTitle: string;
  fileToUpload: any;
  formData: any;
  discussionId: string;
  activeModalRef: NgbModalRef;
  obj: any;

  @Output() addAttachmentData = new EventEmitter();
  @Output() refreshDiscussions = new EventEmitter();

  /**
   * element ref of modal
   * @memberof AttachmentsModalComponent
   */
  @ViewChild('attachmentPopup', { static: true })
  attachmentModalContentReference: ElementRef;

  constructor(
    private modalService: NgbModal,
    private dataService: DiscussionsDataService
  ) { }

  ngOnInit() { }

  /**
   * function to open modal
   * @param title: string title of the modal
   * @param className: string user defined class name
   * @memberof AttachmentsModalComponent
   */

  open(title: string, className?: string, discussionId?: string) {
    this.modalTitle = title;
    this.discussionId = discussionId;

    if (className === undefined || className === null || className === '') {
      this.activeModalRef = this.modalService.open(
        this.attachmentModalContentReference,
        { windowClass: 'tc-modal tc-normal-modal' }
      );
    } else {
      this.activeModalRef = this.modalService.open(
        this.attachmentModalContentReference,
        {
          windowClass: 'tc-modal ' + className,
          backdrop: 'static',
          keyboard: false
        }
      );
    }
  }

  postMethod(files: FileList) {
    console.log('In post', files);
    this.fileToUpload = files.item(0);

    this.formData = new FormData();
    this.obj = {
      formData: this.formData,
      discussion: this.discussionId
    };
    this.formData.append('file', this.fileToUpload, this.fileToUpload.name);
    return false;
  }

  /**
   * Save uploaded file via parent component.
   */

  onSaveAttachment() {
    if (this.formData) {
      this.addAttachmentData.emit(this.obj);
      this.activeModalRef.close();
    } else {
      console.log('Image not Uploaded');
    }
  }
}
