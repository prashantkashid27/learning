import { Component, OnInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DiscussionsDataService } from 'src/modules/core/discussions-data.service';
import { IUser, IFor, IUserData } from 'src/modules/models/discussions-data.models';

@Component({
    selector: 'discussions-edit',
    templateUrl: './edit-modals.component.html',
    styleUrls: ['./edit-modals.component.scss']
})
export class EditModalComponent implements OnInit {
    question = false;
    response = false;
    editQuestionTitle = false;
    editResponseTitle = false;
    addResponseTitle = false;
    addCommentTitle = false;
    editCommentTitle = false;
    addQuestionTitle = false;

    editedQuestionValue: any;
    editComment: any;
    result: any;
    editedResponseValue: any;
    ifHeader: boolean;
    newResponse: string;
    newComment: string;
    toUpdateData: any;
    userName: IUser[] = [];
    showPopup = true;
    questionEntered: string;
    forContacts: IFor[] = [];
    questionError = false;
    selectedContacts: string;
    toUserList: Array<any> = [];
    fromUserList: Array<any> = [];
    enableEdit: boolean = true;
    @Output() payload = new EventEmitter();
    @Output() refreshDiscussions = new EventEmitter();

    /**
     * holds modal title
     * @memberof EditModalComponent
     */
    modalTitle: string;

    constructor(private modalService: NgbModal, private dataService: DiscussionsDataService) { }
    /**
     * element ref of modal
     * @memberof EditModalComponent
     */
    @ViewChild('editPopup', { static: true })
    editModalContentReference: ElementRef;

    ngOnInit() {
        this.ifHeader = false;
        this.dataService.getUsers().subscribe((users: IUserData[]) => {
            this.toUserList = users;
            this.fromUserList = users;
        });
    }


    /**
     * function to open modal
     * @param title: string title of the modal
     * @param className: string user defined class name
     * @memberof EditModalComponent
     */

    open(title, className, enableEdit?) {
        this.modalTitle = title;

        if (title === 'Add Question') {
            this.questionEntered = '';
            this.editQuestionTitle = false;
            this.editResponseTitle = false;
            this.addResponseTitle = false;
            this.addCommentTitle = false;
            this.editCommentTitle = false;
            this.addQuestionTitle = true;
            this.getUpdatedData();
        }
        if (title === 'Edit Question') {
            this.editQuestionTitle = true;
            this.editResponseTitle = false;
            this.addResponseTitle = false;
            this.addCommentTitle = false;
            this.editCommentTitle = false;
            this.addQuestionTitle = false;
            this.getUpdatedData();
        }
        if (title === 'Add Response') {
            this.newResponse = '';
            this.addResponseTitle = true;
            this.editQuestionTitle = false;
            this.editResponseTitle = false;
            this.addCommentTitle = false;
            this.editCommentTitle = false;
            this.addQuestionTitle = false;
            this.getUpdatedData();
        }
        if (title === 'Edit Response') {
            this.editResponseTitle = true;
            this.addResponseTitle = false;
            this.editQuestionTitle = false;
            this.addCommentTitle = false;
            this.editCommentTitle = false;
            this.addQuestionTitle = false;
            this.getUpdatedData();
        }
        if (title === 'Add Comment') {
            this.newComment = '';
            this.editResponseTitle = false;
            this.addResponseTitle = false;
            this.editQuestionTitle = false;
            this.editCommentTitle = false;
            this.addQuestionTitle = false;
            this.addCommentTitle = true;
            this.getUpdatedData();
        }
        if (title === 'Edit Comment') {
            enableEdit = false;
            this.editResponseTitle = false;
            this.addResponseTitle = false;
            this.editQuestionTitle = false;
            this.addQuestionTitle = false;
            this.addCommentTitle = false;
            this.editCommentTitle = true;
            this.getUpdatedData();
        }
        if (className === undefined || className === null || className === '') {
            this.modalService.open(this.editModalContentReference, { windowClass: 'tc-modal tc-normal-modal' });
        } else {
            this.modalService.open(this.editModalContentReference, {
                windowClass: 'tc-modal ' +
                    className, backdrop: 'static', keyboard: false

            });
        }
    }

    onSelectionChange(event) {
        this.forContacts = event;
        console.log('on selection ', this.forContacts);
        const forContacts = event.dropdownItems;
        const selectedDDItems = forContacts.filter(item => item.visible);
        this.selectedContacts = selectedDDItems.map(item => { return { _id: item._id } });
        console.log('this.sel', this.selectedContacts);
    }

    /**
     * Get discussion data as per provided discussion id
     */
    getUpdatedData() {
        if (this.editResponseTitle) {
            this.toUpdateData = this.dataService.getResponseId();
            if (this.toUpdateData) {
                this.dataService.getDetails(this.toUpdateData.discussion).subscribe(resp => {
                    this.result = resp;
                    // tslint:disable-next-line: max-line-length
                    this.editedResponseValue = this.result.questions.find(item => item._id === this.toUpdateData.question).responses.find(res => res._id === this.toUpdateData.response).text;
                }, (error: any) => { console.log(error); });

            }
        } else {
            this.toUpdateData = this.dataService.getDiscussionId();
            if (this.toUpdateData) {
                this.dataService.getDetails(this.toUpdateData.discussion).subscribe(resp => {
                    this.result = resp;
                    console.log('result', this.result);
                    if (this.result.status === 'CLOSE') {
                        this.enableEdit = false;
                    } else {
                        this.enableEdit = true;

                    }
                    if (this.editQuestionTitle) {
                        this.editedQuestionValue = this.result.questions.find(item => item._id === this.toUpdateData.question).text;
                    }
                    if (this.editCommentTitle) {
                        this.editComment = this.result.comments;
                    }
                }, (error: any) => {
                    console.log(error);
                });

            }
        }
    }

    /**
     * emits the updated data to parent component.
     */
    onSave() {
        if (this.addCommentTitle) {
            if (this.result._id === this.toUpdateData.discussion) {
                this.result.comments = this.newComment;
            }
            this.payload.emit(this.result);
            this.modalService.dismissAll('Discussion data saved');
        } else if (this.editCommentTitle) {
            if (this.result._id === this.toUpdateData.discussion) {
                this.result.comments = this.editComment;
            }
            this.payload.emit(this.result);
            this.modalService.dismissAll('Discussion data saved');
        }

        if (this.editResponseTitle) {
            this.result.questions = this.result.questions.map(item => {
                if (item._id === this.toUpdateData.question) {
                    item.responses.map(res => {
                        if (res._id === this.toUpdateData.response) {
                            res.text = this.editedResponseValue;
                        }
                        return res;
                    });
                }
                return item;
            });

            this.payload.emit(this.result);
            this.modalService.dismissAll('Discussion data saved');
        } else if (this.addResponseTitle) {
            this.result.questions.find(item => {
                if (item._id === this.toUpdateData.question) {
                    item.responses.push({ text: this.newResponse });
                }
            });
            this.payload.emit(this.result);
            this.modalService.dismissAll('Discussion data saved');
        }
        if (this.editQuestionTitle) {
            this.result.questions = this.result.questions.map(item => {
                if (item._id === this.toUpdateData.question) { item.text = this.editedQuestionValue; }
                return item;
            });
            this.payload.emit(this.result);
            this.modalService.dismissAll('Discussion data saved');
        } else if (this.addQuestionTitle) {
            if (!this.questionEntered) {
                this.questionError = true;
            }
            if (this.questionEntered) {
                if (this.result._id === this.toUpdateData.discussion) {
                    this.result.questions.push({ for: this.selectedContacts, text: this.questionEntered });
                    console.log('ques', this.result);
                }
                this.payload.emit(this.result);
                this.modalService.dismissAll('Discussion data saved');
            }

        }

    }

}
