export enum EnmStatus {
    open = 'OPEN',
    close = 'CLOSE',
    all = 'ALL'
}

export interface IResponse {
    _id: any;
    text: string;
    from: IAuthor;
    date: Date;
}

export interface IQuestion {
    _id: any;
    text: string;
    from: IAuthor;
    for: IAuthor;
    date: Date;
    responses: Array<IResponse>;
}

export interface IName {
    firstName: string;
    lastName: string;
}

export interface IAuthor {
    _id: any;
    name: IName;
    email: string;
    role: string;
}

export interface IDiscussion {
    _id: any;
    questions: Array<IQuestion>;
    point: string;
    author: IAuthor;
    project: string;
    release: string;
    status: EnmStatus;
    comments?: string;
    lastupdated: Date;
    attachments?: Array<IAttachment>;
}

export interface IAttachment {
    _id: string;
    fileName: string;
    originalName: string;
}

export class Discussion {
    _id: any;
    questions: Array<IQuestion>;
    point: string;
    author: IAuthor;
    project: string;
    release: string;
    status: EnmStatus;
    comments: string;
    lastupdated: Date;
    attachments?: Array<IAttachment>;
    isCollapsed?: boolean;

    constructor(data: IDiscussion) {
        this._id = data._id;
        this.point = data.point;
        this.project = data.project;
        this.release = data.release;
        this.status = data.status;
        this.comments = data.comments;
        this.lastupdated = data.lastupdated;
        this.attachments = data.attachments;
        this.isCollapsed = false;

        this.author = data.author;
        this.questions = data.questions;
    }
}
