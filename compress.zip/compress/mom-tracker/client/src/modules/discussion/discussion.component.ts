/**
 * Core angular modules
 */
import { Component, ViewEncapsulation, OnInit, ViewChild } from '@angular/core';
import { HTTPService } from '../core/http.service';
import { Router, ActivatedRoute } from '@angular/router';
import { IDiscussion, EnmStatus } from './discussion.data';
import { DiscussionsDataService } from '../core/discussions-data.service';
import { IRelease } from '../shared/metaData.data';
import { SearchInfo, IUserData, ProjectDetails } from '../models/discussions-data.models';
import { DiscussionModalComponent } from '../modal-popup/discussion-modal/discussion-modal.component';
import { ToastMessageData } from 'tc-angular-components';
import { ContextService } from '../core/context.service';

@Component({
    selector: 'app-discussion',
    templateUrl: './discussion.component.html',
    styleUrls: [
        './discussion.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
})
export class DiscussionComponent implements OnInit {

    projectList: Array<any> = [];
    releaseList: Array<any> = [];
    projectSelected: string;
    releaseSelected: string;
    statusSelected = 'all';
    fromUserSelected: string;
    toUserSelected: string;
    discussionsData: IDiscussion[] = [];
    toUserList: Array<any> = [];
    fromUserList: Array<any> = [];
    users: IUserData[];
    isSearchClicked = false;
    discussionsFetched = false;
    /**
     * Index of the dropdown item to be selected for projects
     */
    defaultProjectSelection = -1;
    /**
     * Index of the dropdown item to be selected for releases
     */
    defaultReleaseSelection = -1;
    /**
     * An id of the discussion to select/highlight
     */
    discussionSelected = -1;
    showSuccessToast: boolean;
    toastMessage: ToastMessageData = {
        bodyText: 'Discussion Data Saved successfully',
        titleText: 'Toast Title'
    };

    projectDetails: ProjectDetails;

    /**
     * element ref of modal
     * @memberof DiscussionModalComponent
     */
    @ViewChild(DiscussionModalComponent, { static: true }) discussionModal: DiscussionModalComponent;

    constructor(
        private http: HTTPService,
        private router: Router,
        private dataService: DiscussionsDataService,
        private activatedRoute: ActivatedRoute,
        private contextService: ContextService
    ) {
        this.activatedRoute.queryParams.subscribe((params) => {
            this.projectSelected = params['project'];
            this.releaseSelected = params['release'];
            this.discussionSelected = params['discussion'];
        });
    }

    ngOnInit(): void {
        this.getProjectReleaseMetaData();
        this.getUsersList();
        this.showSuccessToast = false;
    }

    /**
     * Gets Project and Release metadata
     */
    getProjectReleaseMetaData() {
        this.dataService.getProjectReleaseMetaData().subscribe((response: { projects: IRelease[], releases: IRelease[] }) => {
            if (response) {
                this.projectList = response.projects;
                this.releaseList = response.releases;
                // Project and release should be selected only if they are present in the url
                if (this.projectSelected && this.releaseSelected) {
                    this.defaultProjectSelection = this.projectList.findIndex((project) => project._id === this.projectSelected);
                    this.defaultReleaseSelection = this.releaseList.findIndex((release) => release._id === this.releaseSelected);
                    this.searchDiscussionData();
                }
            }
        }, (error: any) => {
            console.log('admin/getMetaData', error);
        });
    }

    searchDiscussionData() {
        this.isSearchClicked = true;
        if (this.projectSelected && this.releaseSelected) {
            const searchInfo: SearchInfo = {
                project: this.projectSelected,
                release: this.releaseSelected,
                status: EnmStatus[this.statusSelected]
            };
            if (this.toUserSelected !== '-1') {
                searchInfo.for = this.toUserSelected;
            }
            if (this.fromUserSelected !== '-1') {
                searchInfo.author = this.fromUserSelected;
            }
            this.contextService.setSearchInfo(searchInfo);
            this.getDiscussionData(true);
        }
    }

    /**
     * Finds discussion data for selected project and release
     */
    getDiscussionData(sortByUpdateTime?: boolean) {
        // if any seachField is selected and search is not performed, then set fields to last state.
        this.setSearchInfoToLastState();

        const searchInfo: SearchInfo = this.contextService.getSearchInfo();
        if (searchInfo.project && searchInfo.release) {
            this.dataService.getDiscussions(searchInfo, sortByUpdateTime).subscribe((discussions: IDiscussion[]) => {
                this.discussionsFetched = true;
                this.discussionsData = discussions;
            }, (error: any) => {
                console.log('error in getDiscussion data', error);
                this.discussionsData = [];
            });
        }
    }

    setSearchInfoToLastState() { }

    getUsersList() {
        this.toUserList = [];
        this.fromUserList = [];
        const defaultSelect = {
            name: 'Select',
            _id: '-1',
            value: -1
        };
        this.dataService.getUsers().subscribe((users: IUserData[]) => {
            this.users = users;
            this.toUserList.push(defaultSelect);
            this.fromUserList.push(defaultSelect);
            this.toUserList = this.toUserList.concat(users);
            this.fromUserList = this.fromUserList.concat(users);
        });
    }

    onSelectionChange(data: any, isProjectSelection?: boolean) {
        if (isProjectSelection) {
            this.projectSelected = data.selectedObject._id;
        } else {
            this.releaseSelected = data.selectedObject._id;
        }
        if (this.projectSelected && this.releaseSelected) {
            this.projectDetails = {
                projectId: this.projectSelected,
                releaseId: this.releaseSelected
            };
        }
    }

    setUsersInFilter(option, isFromUsers: boolean) {
        if (isFromUsers) {
            this.fromUserSelected = option.selectedObject._id;
        } else {
            this.toUserSelected = option.selectedObject._id;
        }
    }

    onBackClick() {
        this.router.navigate(['../app/dashboard']);
    }


    /**
     * Opens modal to add new discussion data
     */
    addNewDiscussion() {
        console.log('OPEN', this.discussionModal);
        this.discussionModal.open('Add Discussion', 'tc-modal-50');
    }

    /**
     * Receives payload to add discussion data and further calls respective API
     */
    addDiscussionData(event) {
        if (event) {
            this.dataService.addNewDisucssion(event).subscribe(resp => {
                this.getDiscussionData();
                console.log(resp);
            }, (error: any) => {
                console.log(error);
            });
        }
    }

    /**
     * Shows toast message on success of discussion data saved
     */
    showToast(event) {
        this.showSuccessToast = event;
    }
}
