/**
 * Core angular modules
 */
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/**
 * Application component imports
 */
import { DiscussionComponent } from './discussion.component';

/**
 * Module child routes
 */
const routes: Routes = [
  { path: '', redirectTo: 'tracker' },
  { path: 'tracker', component: DiscussionComponent }
];

/**
 * This is child module router which will be loaded lazily in root application
 */
export const DiscussionRouting: ModuleWithProviders = RouterModule.forChild(routes);
