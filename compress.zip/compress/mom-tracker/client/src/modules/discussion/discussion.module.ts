/**
 * Core angular modules
 */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

/**
 * Third party library modules - bootstrap, primeng etc
 */
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

/**
 * Travelclick library tc-angular-components modules
 */
import { DropdownModule } from 'tc-angular-components';
import { ToastModule } from 'tc-angular-components';

/**
 * Application level components
 */
import { DiscussionRouting } from './discussion.routing';
import { DiscussionComponent } from './discussion.component';
import { HTTPService } from '../core/http.service';
import { TableComponent } from '../table/table.component';
import { DiscussionModalComponent } from '../modal-popup/discussion-modal/discussion-modal.component';
import { AttachmentsModalComponent } from '../modal-popup/attachments-modal/attachments-modal.component';
import { ViewAttachmentModalComponent } from '../modal-popup/view-attachment-modal/view-attachment-modal.component';
import { EditModalComponent } from '../modal-popup/edit-modals/edit-modals.component';

import { DiscussionsDataService } from '../core/discussions-data.service';
import { ConfirmationModalComponent } from '../modal-popup/confirmation-modal/confirmation-modal';
import { UtilityService } from '../core/utility.service';

/**
 * The bootstrap module
 * This is actual child application module which will be loaded lazily in root application
 */
@NgModule({
    declarations: [
        DiscussionComponent,
        TableComponent,
        DiscussionModalComponent,
        AttachmentsModalComponent,
        ViewAttachmentModalComponent,
        EditModalComponent,
        ConfirmationModalComponent
    ],
    imports: [
        CommonModule,
        NgbModule,
        FormsModule,
        DiscussionRouting,
        DropdownModule,
        FormsModule,
        ToastModule
    ],
    exports: [
        DiscussionComponent
    ],
    providers: [
        HTTPService,
        DiscussionsDataService,
        UtilityService
    ],
    bootstrap: [DiscussionComponent]
})
export class DiscussionModule { }

