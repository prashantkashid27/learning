export enum UserRole {
    DEV = 'DEV',
    PM = 'PM',
    BA = 'BA',
    ADMIN = 'ADMIN'
}
