export interface IRelease {
    _id?: string;
    name: string;
    label: string;
}

export interface IProject {
    _id?: string;
    name: string;
    label: string;
}
