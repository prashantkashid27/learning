export const APP_CONSTANT = {
    config: {
        apiUrl: 'https://api-t5.travelclick.com/{{api_module_context_path}}/',
        tokenData: {
            issuerKey: 'idpv2key',
            sub: 'ihsuryakant',
            role: 'System',
            property: '1001',
            rateid: '580582',
            custom1: 'custom1',
            chaincode: 'SR1',
            user_permission: '3',
            uid: '580582'
        }
    }
};
