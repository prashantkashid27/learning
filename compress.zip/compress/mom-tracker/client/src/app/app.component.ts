import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'project-root',
  templateUrl: './app.component.html',
  styleUrls: [
    '../../node_modules/tc-styles/dist/scss/main.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'Discussion Tracker';
}
