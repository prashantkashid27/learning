import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { routing } from './app-routing';
import { AppComponent } from './app.component';
import { TcSessionService } from 'tc-angular-services';
import { NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from 'src/modules/login/login.component';
import { FormsModule } from '@angular/forms';
import { HTTPService } from 'src/modules/core/http.service';
import { HttpInterceptorService } from '../modules/core/http.interceptor.service';
import { ContextService } from 'src/modules/core/context.service';
import { LoaderComponent } from 'src/modules/loader/loader.component';
import { LoaderService } from 'src/modules/loader/loader.service';
import { HomeComponent } from 'src/modules/home/home.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LoaderComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    NgbModule,
    NgbTooltipModule,
    HttpClientModule,
    routing
  ],
  providers: [
    HTTPService,
    ContextService,
    LoaderService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    TcSessionService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
