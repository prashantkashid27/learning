import { Routes, RouterModule } from '@angular/router';

/**
 * Core angular modules
 */
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from 'src/modules/login/login.component';
import { HomeComponent } from 'src/modules/home/home.component';
/**
 * Root app routes to load child modules lazily - here we have to load only one child module
 */
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'app', 
    component : HomeComponent,
    children: [ 
      { path: 'dashboard', loadChildren: () => import('../modules/dashboard/dashboard.module').then(m => m.DashboardModule) },
      { path: 'discussion', loadChildren: () => import('../modules/discussion/discussion.module').then(m => m.DiscussionModule) },
      { path: 'adminDashboard', loadChildren: () => import('../modules/admin-dashboard/admin-dashboard.module')
       .then(m => m.AdminDashboardModule) }
    ]}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
