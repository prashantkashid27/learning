var mongoose = require('mongoose');

var storySchema = new mongoose.Schema({
    title: String,
    year: String,
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Person'
    }
}, { collection: 'Stories' });
var Story = mongoose.model('Story', storySchema);
module.exports = Story;