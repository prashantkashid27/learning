module.exports = {
    ROLES: ['BA', 'DEV', 'ADMIN', 'PM'],
    STATUS: ['OPEN', 'CLOSE', 'PENDING'],
    DBCONFIG: {
        url: "mongodb://localhost:27017/MoMTracker",
        attachmentPath: 'attachments/'
    },
    ERROR: {
        INVALID_RELEASE_PROJECT: 'INVALID_RELEASE_PROJECT',
        NO_RECORDS_FOUND: 'NO_RECORDS_FOUND',
        INTERNAL_SERVER_ERROR: 'INTERNAL_SERVER_ERROR',
        INVALID_OR_MISSING_FIELD: 'INVALID_OR_MISSING_FIELD'
    }
}
