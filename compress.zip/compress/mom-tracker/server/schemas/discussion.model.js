var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var constants = require('./constant.model');

var discussionSchema = Schema({
    point: String,
    release: {
        type: Schema.Types.ObjectId,
        ref: 'Releases'
    },
    project: {
        type: Schema.Types.ObjectId,
        ref: 'Projects'
    },
    questions: [{
        type: Schema.Types.ObjectId,
        ref: 'Questions'
    }],
    author: {
        type: Schema.Types.ObjectId,
        ref: 'Users'
    },
    status: {
        type: String,
        enum: constants.STATUS,
        required: true
    },
    attachments: [{
        fileName: String,
        originalName: String
    }],
    lastupdated: {
        type: Date,
        default: Date.now
    },
    comments: String
});

const DiscussionModel = mongoose.model('Discussions', discussionSchema, 'Discussions');
module.exports = DiscussionModel;