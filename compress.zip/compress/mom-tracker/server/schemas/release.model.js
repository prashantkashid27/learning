var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var releaseSchema = Schema({
    name: String,
    label: String
});
const ReleaseModel = mongoose.model('Releases', releaseSchema, 'Releases');
module.exports = ReleaseModel;