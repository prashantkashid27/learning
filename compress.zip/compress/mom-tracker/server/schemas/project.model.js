var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var projectSchema = Schema({
    name: String,
    label: String
});
const ProjectModel = mongoose.model('Projects', projectSchema, 'Projects');
module.exports = ProjectModel;