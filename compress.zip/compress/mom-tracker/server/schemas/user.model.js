var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var constants = require('./constant.model');


var userSchema = Schema({
    name: {
        firstName: String,
        lastName: String
    },
    email: String,
    password: String,
    role: {
        type: String,
        enum: constants.ROLES,
        required: true
    }
});

const UserModel = mongoose.model('Users', userSchema, 'Users');
module.exports = UserModel;