var mongoose = require('mongoose');
var addressSchema = mongoose.Schema({
    city: String,
    state: String
});

var personSchema = new mongoose.Schema({
    name: String,
    age: String,
    address: {
        type: addressSchema
    }
}, { collection: 'Person' });
const Person = mongoose.model('Person', personSchema);
module.exports = Person;

