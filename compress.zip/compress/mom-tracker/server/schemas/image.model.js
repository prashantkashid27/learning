var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var attachmentSchema = Schema({
    img: { data: Buffer, contentType: String }
});
var AttachmentModel = mongoose.model('Attachments', attachmentSchema, 'Attachments');
module.exports = AttachmentModel;