var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var responseSchema = Schema({
    text: String,
    from: {
        type: Schema.Types.ObjectId,
        ref: 'Users'
    },
    tagged: Boolean,
    date: {
        type: Date,
        default: Date.now
    }
});

var questionSchema = Schema({
    text: String,
    from: {
        type: Schema.Types.ObjectId,
        ref: 'Users'
    },
    for: [{
        type: Schema.Types.ObjectId,
        ref: 'Users'
    }],
    responses: [responseSchema],
    date: {
        type: Date,
        default: Date.now
    }
});

const QuestionModel = mongoose.model('Questions', questionSchema, 'Questions');
module.exports = QuestionModel;