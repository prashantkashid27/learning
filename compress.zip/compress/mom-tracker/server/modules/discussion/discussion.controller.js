var discussionController = {}
var QuestionModel = require('../../schemas/question.model');
var DiscussionModel = require('../../schemas/discussion.model');
var mongoose = require('mongoose');
var errorConstant = require('../../schemas/constant.model').ERROR;
var dbConfig = require('../../schemas/constant.model').DBCONFIG;

/**image handling */
var fs = require('fs'),
    path = require('path');

discussionController.getImage = function (req, res) {
    var reqObj = req.params;
    var filePath = path.join(path.resolve(), `attachments/${reqObj.id}`);
    res.sendFile(path.join(filePath), function (error, response) {
        if (error) {
            res.status(404).send({
                code: errorConstant.NO_RECORDS_FOUND,
                message: 'No records found'
            });
        }
    });
}

discussionController.uploadImage = function (req, res) {
    const file = req.file
    const id = req.params.id;
    DiscussionModel.updateOne({ "_id": id }, {
        $push: {
            attachments: {
                fileName: req.file.filename,
                originalName: req.file.originalname,
            }
        },
        $set: { lastupdated: Date.now() }
    }, function (error, response) {
        res.send(file);
    });
}


/**ADD DISCUSSION */
discussionController.addDiscussion = function (req, res) {
    var responseData = [];
    var reqObj = req.body;
    /* if(!reqObj.release){
        res.status(400).send({
            message: "Release required"
        });
        return;    
    } */
    if (!reqObj.reference) {
        res.status(400).send({
            code: errorConstant.INVALID_OR_MISSING_FIELD,
            message: "Reference required"
        });
        return;
    }
    if (!reqObj.question.text || reqObj.question.text.length == 0) {
        res.status(400).send({
            code: errorConstant.INVALID_OR_MISSING_FIELD,
            message: "Question required"
        });
        return;
    }
    if (reqObj.response) {
        for (var r = 0; r < reqObj.response.length; r++) {
            var rData = {
                text: reqObj.response[r],
                from: req.headers.user
            }
            responseData.push(rData);
        }
    }

    var q1 = new QuestionModel({
        text: reqObj.question.text,
        from: req.headers.user,
        for: reqObj.question.for,
        responses: responseData
    });

    q1.save(function (err) {
        if (err) {
            res.status('500').send({
                code: errorConstant.INTERNAL_SERVER_ERROR,
                message: "internal server error"
            });
            return;
        }
        var d1 = new DiscussionModel({
            point: reqObj.reference,
            questions: [q1._id],
            author: req.headers.user,
            release: reqObj.release,
            project: reqObj.project,
            status: "OPEN",
            comments: reqObj.comment
        });
        d1.save(function (err) {
            if (err) throw err;
            res.send({
                success: true
            });
        });
    });
}

/**ADD QUESTION TO DISCUSSION */
discussionController.getDiscussions = function (req, res) {
    var reqObj = req.body;
    var questionQueryRef = {};
    if (!mongoose.Types.ObjectId.isValid(reqObj.release) || !mongoose.Types.ObjectId.isValid(reqObj.project)) {
        res.status('500').send({
            code: errorConstant.INVALID_RELEASE_PROJECT,
            message: 'invalid release or project'
        })
        return;
    }

    var discussionQueryRef = {
        release: reqObj.release,
        project: reqObj.project
    };
    /**modify discussion query */
    if (reqObj.status) {
        if (reqObj.status != 'ALL') {
            discussionQueryRef.status = reqObj.status;
        }
    }
    if (reqObj.author) {
        discussionQueryRef.author = reqObj.author;
    }
    /**modify question query */
    if (reqObj.for) {
        questionQueryRef.for = { $eq: reqObj.for };
    }
    DiscussionModel.find(discussionQueryRef)
        .populate({ path: 'author', select: 'name email' })
        .populate({
            path: 'questions',
            match: questionQueryRef,
            populate: [{
                path: 'for', select: 'name email'
            }, {
                path: 'from', select: 'name email'
            }]
        }).exec((err, response) => {
            if (err) {
                res.status('500').send({
                    code: errorConstant.INTERNAL_SERVER_ERROR,
                    message: "internal server error"
                });
                return;
            }
            for (var q = response.length - 1; q >= 0; q--) {
                if (response[q].questions.length == 0) {
                    response.splice(q, 1);
                }
            }
            if (response && response.length === 0) {
                res.status(404).send({
                    code: errorConstant.NO_RECORDS_FOUND,
                    message: "No records Found"
                })
            } else {
                res.send(response);
            }
        });
}

/**GET  SPECIFIC DISCUSSION*/
discussionController.getDiscussion = function (req, res) {
    DiscussionModel.findOne({ "_id": req.params.qId }).populate({
        path: 'author', select: 'name email'
    }).populate({
        path: 'questions',
        populate: [{
            path: 'for', select: 'name email'
        }, {
            path: 'from', select: 'name email'
        }]
    }).exec((err, response) => {
        if (!response) {
            res.status(404).send({
                code: errorConstant.NO_RECORDS_FOUND,
                message: "No records found"
            });
        } else {
            res.send(response);
        }
    });
}

discussionController.updateQuestion = function (req, res) {
    var questionObj = req.body;
    var questArr = [];
    var questionsProcessed = 0;
    questionObj.questions.forEach(element => {
        QuestionModel.find({ "_id": element._id }).then(function (response) {
            if (response && response.length) {
                questArr.push(element._id);
                forArray = [];
                for (var i = 0; i < element.for.length; i++) {
                    forArray.push(element.for[i]._id);
                }
                var responseData = [];
                for (var r = 0; r < element.responses.length; r++) {
                    if (element.responses[r]._id) {
                        responseData.push(element.responses[r]);
                    } else {
                        var rData = {
                            text: element.responses[r].text,
                            from: req.headers.user
                        }
                        responseData.push(rData);
                    }
                }
                QuestionModel.updateOne({ "_id": element._id }, {
                    $set: {
                        for: forArray,
                        text: element.text,
                        responses: responseData
                    }
                }, function (error, response) {
                    if (error) throw error;
                    questionsProcessed++;
                    if (questionsProcessed >= questionObj.questions.length) {
                        discussionController.allQuestionsProcessed(questionObj, questArr, res);
                    }
                });
            } else {
                var q1 = new QuestionModel({
                    text: element.text,
                    from: req.headers.user,    //need to think on capturing from
                    for: element.for,
                    responses: []
                });
                q1.save(function (err) {
                    if (err) throw err;
                    questArr.push(q1._id);
                    questionsProcessed++;
                    discussionController.allQuestionsProcessed(questionObj, questArr, res);
                });
            }
        });
    });

    discussionController.allQuestionsProcessed = function (questionObj, questArr, res) {
        var newQuestions = [];
        var deletedQuestions = []
        DiscussionModel.findOne({ "_id": questionObj._id }, "questions", function (error, response) {
            for (var q = 0; q < questionObj.questions.length; q++) {
                if (questionObj.questions[q]._id) {
                    newQuestions.push(questionObj.questions[q]._id.replace(/'/g, '"'));
                }
            }
            if (response && response.questions.length > 0) {
                if (response.questions.length > 0 && newQuestions.length > 0) {
                    deletedQuestions = response.questions.filter(function (el) {
                        return newQuestions.indexOf(el.toString()) < 0;
                    });
                }
            }
            //console.log('deletedQuestions', deletedQuestions)
            if (deletedQuestions.length > 0) {
                // if found deleted questions, delete first and then update discussion
                QuestionModel.deleteMany({ "_id": { $in: deletedQuestions } }, function (error, response) {
                    if (error) res.json({ status: 500, error: error });
                    //console.log(response);
                    discussionController.updateDiscussion(questionObj, questArr, res);
                });
            } else {
                discussionController.updateDiscussion(questionObj, questArr, res);
            }
        });
    }
}

discussionController.updateDiscussion = function (questionObj, questArr, res) {
    // update discussion model
    DiscussionModel.updateOne({ "_id": questionObj._id }, {
        questions: questArr,
        $set: {
            point: questionObj.point,
            status: questionObj.status,
            comments: questionObj.comments,
            lastupdated: Date.now()
        }
    }).then(function (response) {
        //console.log('updateOne discussion', response);
        res.send({
            success: true
        });
    });
}

discussionController.parseResponseArray = function (reqObj) {
    var responseData = [];
    for (var r = 0; r < reqObj.response.length; r++) {
        var rData = {
            text: reqObj.response[r],
            from: reqObj.from
        }
        responseData.push(rData);
    }
    return responseData;
}

discussionController.deleteDiscussion = function (req, res, next) {
    DiscussionModel.findOne({ _id: req.params.id }, async function (error, response) {
        if (error) {
            throw error;
        }
        if (response == null || response == undefined) {
            res.status(404).send({
                code: errorConstant.NO_RECORDS_FOUND,
                message: 'No records found'
            });
            return;
        }
        if (!req.params.qId && !req.params.rId) {
            //delete discussion
            try {
                await QuestionModel.deleteMany({ _id: { $in: response.questions } });
            } catch (err) {
                //logger for error;                  
            } finally {
                try {
                    await discussionController.deleteFiles(response.attachments);
                } catch (err) {
                    //log error here                    
                } finally {
                    //still delete discussion in case any error occurs
                    var discussionResponse = await DiscussionModel.findByIdAndDelete(req.params.id);
                    res.send(discussionResponse);
                    return;
                }
            }
        }
        if (req.params.qId && !req.params.rId) {
            //find by question
            discussionController.deleteQuestion(req, res, req.params.qId, true);
            //pending - remove entry from discussion table
            return;
        }
        if (req.params.qId && req.params.rId) {
            //find by question
            QuestionModel.findByIdAndUpdate(req.params.qId,
                { $pull: { responses: { _id: req.params.rId } } },
                (error, response) => {
                    //console.log(error, response)
                    if (error) {
                        throw error;
                    }
                });
            res.send({ success: true });
        }
    });
}

discussionController.deleteFiles = function (files, callback) {
    var i = files.length;
    return new Promise((resolve, reject) => {
        if (files.length == 0) {
            resolve(true);
        }
        files.forEach(function (file) {
            //console.log(file.fileName)
            fs.unlink(dbConfig.attachmentPath + file.fileName, function (err) {
                i--;
                if (err) {
                    reject(err);
                    return;
                } else if (i <= 0) {
                    resolve(true);
                }
            });
        });
    });
}

discussionController.deleteQuestion = function (req, res, qId, sendResponse) {
    QuestionModel.findByIdAndRemove(qId, (err, question) => {
        if (err) {
            throw err;
        }
        if (!question) {
            res.status(400).send({
                code: errorConstant.NO_RECORDS_FOUND,
                message: "Question doesn't exist"
            });
            return
        }
        if (sendResponse) {
            res.send({ success: true });
        }
    });
}

discussionController.updateStatus = function (req, res) {
    var reqObj = req.body;
    DiscussionModel.findByIdAndUpdate(reqObj.id, {
        $set: {
            status: reqObj.status,
            lastupdated: Date.now()
        }
    }, (error, response) => {
        if (error) {
            throw error;
        }
        res.send({
            success: true
        });
    });
}

discussionController.tagResponse = async function (req, res) {
    var reqObj = req.body;
    if (reqObj.tagValue) {
        await QuestionModel.findOneAndUpdate({ '_id': reqObj.qid, 'responses': { $elemMatch: { tagged: true } } }, {
            $set: { 'responses.$.tagged': false }
        });
    }
    QuestionModel.updateOne({ '_id': reqObj.qid, 'responses._id': reqObj.rid }, {
        $set: { 'responses.$.tagged': reqObj.tagValue }
    }, (error, response) => {
        if (error) {
            throw error;
        }
        //console.log(response);
        res.send({
            success: true
        })
    });
}

module.exports = discussionController;