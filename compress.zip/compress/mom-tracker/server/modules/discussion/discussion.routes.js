var express = require('express');
var multer = require('multer');
var path = require('path');
var router = express.Router();
var discussionController = require('./discussion.controller');
var dbConfig = require('../../schemas/constant.model').DBCONFIG;


router.get('/getDiscussion/:qId', discussionController.getDiscussion);
router.get('/getImage/:id', discussionController.getImage);

/**POST/PUT */
router.post('/getDiscussions', discussionController.getDiscussions);
router.post('/addDiscussion', discussionController.addDiscussion);
router.put('/updateDiscussion', discussionController.updateQuestion);

/**PATCH */
router.patch('/status', discussionController.updateStatus);
router.patch('/tagResponse', discussionController.tagResponse);

/**DELETE */
router.delete('/delete/:id/:qId?/:rId?', discussionController.deleteDiscussion);
//router.delete('/delete/:id/:qId?/:rId?', discussionController.deleteDiscussion);

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, dbConfig.attachmentPath)
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})
var upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 100 }    //100KB restriction
});
var type = upload.single('file');
//router.post('/uploadfile/:id', type, discussionController.uploadImage)
router.post('/uploadfile/:id', function (req, res) {
    type(req, res, function (err) {
        if (err) {
            res.status(400).send({
                message: "file size too large"
            });
            return;
        }
        discussionController.uploadImage(req, res);
    });
});


/**VIEW ROUTES */
router.get('/', function (req, res) {
    res.render('get_discussions');
});

router.get('/getForm', function (req, res) {
    res.render('add_discussion');
});

router.get('/updateForm', function (req, res) {
    res.render('update_question');
});

router.get('/uploadImage', function (req, res) {
    res.render('upload_image');
});

module.exports = router;