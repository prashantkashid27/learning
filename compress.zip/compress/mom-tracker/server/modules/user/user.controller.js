var UserModel = require('../../schemas/user.model');
var bcrypt = require('bcrypt');

var userController = {};
userController.getUsers = function (req, res, next) {
    UserModel.find().then(response => res.send(response));
}

userController.getUser = function (req, res, next) {
    UserModel.find({ _id: req.params.userId }, function (error, response) {
        if (response && response.length) {
            res.send(response);
        } else {
            res.status(404).send({
                error: 'No user found'
            })
        }
    });
}

userController.addUser = function (req, res) {
    var userObj = req.body;
    if (!userObj.email) {
        res.status(400).send({
            success: false,
            error: 'email required'
        });
        return;
    }
    if (!userObj.password) {
        res.status(400).send({
            success: false,
            error: 'password required'
        });
        return;
    }
    if (userObj.firstname.length == 0) {
        res.status(400).send({
            success: false,
            error: 'firstname required'
        });
        return;
    }
    UserModel.find({ email: userObj.email }, function (error, response) {
        if (response.length) {
            res.status(400).send({
                success: false,
                error: 'email id exists'
            });
        } else {
            var BCRYPT_SALT_ROUNDS = 12;
            bcrypt.hash(userObj.password, BCRYPT_SALT_ROUNDS)
                .then(function (hashedPassword) {
                    var u1 = new UserModel({
                        name: {
                            firstName: userObj.firstname,
                            lastName: userObj.lastname
                        },
                        email: userObj.email,
                        password: hashedPassword,
                        role: userObj.role
                    });
                    u1.save(function (err) {
                        if (err) throw err;
                        res.send({
                            "success": true
                        });
                    });
                });
        }
        return;
    });
}

userController.authenticateUser = function (req, res) {
    var reqObj = req.body;
    UserModel.findOne({ "email": reqObj.email }, function (error, response) {
        if (error) throw error;
        if (response == null) {
            res.status(400).send({
                message: "User doesn't exists"
            });
            return;
        } else {
            bcrypt.compare(reqObj.password, response.password, function (error, result) {
                if (error) throw error;
                if (result) {
                    res.send({
                        "_id": response._id,
                        "role": response.role
                    });
                } else {
                    res.status(403).send({
                        message: "Authentication failed"
                    })
                }
            });
        }
    });
}

userController.getForm = function (req, res, next) {
    res.render('add_user');
}

userController.getValidationForm = function (req, res) {
    res.render('validate_user');
}

module.exports = userController;