var express = require('express');
var router = express.Router();
var userController = require('./user.controller')

router.get('/', userController.getUsers);
router.get('/getUser/:userId', userController.getUser);
router.post('/addUser', userController.addUser);
router.post('/authenticate', userController.authenticateUser);

/**for view */
router.get('/getForm', userController.getForm);
router.get('/login', userController.getValidationForm);


module.exports = router;