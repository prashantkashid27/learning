var express = require('express');
var router = express.Router();
var adminController = require('./admin.controller');

router.post('/addRelease', adminController.addRelease);
router.post('/addProject', adminController.addProject);
router.get('/getMetadata',adminController.getMetaData);

/**VIEW ROUTES */
router.get('/getReleaseForm', function (req, res) {
    res.render('add_release');
});

router.get('/getProjectForm', function (req, res) {
    res.render('add_project');
});
module.exports = router;