var async = require('async');

var adminController = {};
var ReleaseModel = require('../../schemas/release.model');
var ProjectModel = require('../../schemas/project.model');

adminController.addRelease = function (req, res) {
    var reqObj = req.body;
    ReleaseModel.find({ "name": reqObj.name }, function (error, response) {
        if (response && response.length >= 1) {
            /**release already exists */
            res.status(400).send({
                "message": "release already exists"
            });
        } else {
            var r1 = new ReleaseModel({
                name: reqObj.name,
                label: reqObj.label,
            });
            r1.save(function (err) {
                if (err) throw err;
                console.log(r1._id);
                res.send({
                    "id": r1._id
                });
            });
        }
    });
}

adminController.addProject = function (req, res) {
    var reqObj = req.body;
    ProjectModel.find({ "name": reqObj.name.toLowerCase() }, function (error, response) {
        if (response && response.length >= 1) {
            /**release already exists */
            res.status(400).send({
                "message": "project already exists"
            });
        } else {
            var p1 = new ProjectModel({
                name: reqObj.name.toLowerCase(),
                label: reqObj.name,
            });
            p1.save(function (err) {
                if (err) throw err;
                console.log(p1._id);
                res.send({
                    "id": p1._id
                });
            });
        }
    });
}


adminController.getMetaData = function (req, res) {
    var metadata = {
        projects: [],
        releases: []
    };
    var queries = [];
    queries.push(function (callback) {
        result = ReleaseModel.find({}, function (error, respose) {
            if (error) {
                callback(error);
            }
            callback(null, respose);
        });
    });
    queries.push(function (callback) {
        result = ProjectModel.find({}, function (error, respose) {
            if (error) {
                callback(error);
            }
            callback(null, respose);
        });
    });
    async.parallel(queries, function (error, response) {
        metadata.releases = response[0];
        metadata.projects = response[1];
        res.send(metadata);
    });
}

module.exports = adminController;