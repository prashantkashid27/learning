var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var userData = require('./data/users.json');
var constants = require('../schemas/constant.model');

var url = constants.DBCONFIG.url;
var UserModel = require('../schemas/user.model');

mongoose.connect(url, { useNewUrlParser: true });
var db = mongoose.connection;
db.on('error', () => console.log('connection error'));

db.once('open', async function () {
    console.log('DB connected');
    var pushData = []
    userData.forEach(element => {
        var user = {
            name: {
                firstName: element.name.firstName,
                lastName: element.name.lastName
            },
            email: element.email,
            role: element.role
        }
        pushData.push(user);
    });
    UserModel.create(pushData, function (err, res) {
        console.log(res);
    });
});
